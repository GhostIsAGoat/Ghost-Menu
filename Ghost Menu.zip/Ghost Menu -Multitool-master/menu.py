        .__                    __                                       ___    
   ____ |  |__   ____  _______/  |_    _____   ____   ____  __ __   /\  \  \   
  / ___\|  |  \ /  _ \/  ___/\   __\  /     \_/ __ \ /    \|  |  \  \/   \  \  
 / /_/  >   Y  (  <_> )___ \  |  |   |  Y Y  \  ___/|   |  \  |  /  /\    )  ) 
 \___  /|___|  /\____/____  > |__|   |__|_|  /\___  >___|  /____/   \/   /  /  
/_____/      \/           \/               \/     \/     \/             /__/   ghost menu V1 | Made by  ̶̶.̶̶ ̶̶g̶̶h̶̶o̶̶s̶̶t̶̶ ̶̶.̶̶#0267
 

                                                                                                                                                                                                                                                                                                                                                                                                           

          1. Pinger                                    16. Random Ip Generator
              
          2. Ip Stresser                               17. Steam Account Generator
           
          3. Ip Lookup                                 18. Minecraft & Spotify Generator
         
          4. Port Scanner                              19. Rat Tutorial
          
          5. Open Putty                                20. Sick Fonts (Text etc.)
                          
          6. Dox Tool                                  21. Phone Spoofer (SSL)
                       
          7. USA Fake Info Generator                   22. Sms Bomber (iOS)

          8. 30+ Phishing Sites                        23. Ip-Logger

          9. Extreme Doxing Tool                       24. Botting Panel (All Socials)

         10. Rat/Virus Creator (Github)               25. Instagram ID Searcher
              
         11. Keyword Generator Tool                   26. Fortnite Aimbot/Wallhack

         12. Vpn/Ovh                                  27. EXIT

         13. Open Cyberhub (Hacking Tools And More)   ~ Don't Resell This Tool ~

         14. Open Vedbex (USEFUL TOOLS)               ~ Don't credit it to your own ~

        15. Ascii Art                                ~ Enjoy! :) ~

